  
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

main(int argc, char *argv[])
{
    time_t t;
    int pid,id, min_time = 0, max_time = 0, exact_time = 0, total = 0;

    if (argc < 5)
    {
        fprintf(stderr, "Numero de argumentos incorrecto \n");
        exit(1);
    }

    int i;	

    for(i = 0; i < atoi(argv[1]);i++){
        t = time(NULL);
        
        if ((pid = fork()) == 0) execvp(argv[4],&(argv[4]));
        wait(pid);
        t = time(NULL) - t;
        total = t + total;

        if(t < atoi(argv[2]))
         min_time++;
      else if(t > atoi(argv[3]))
         max_time++;
      else
         exact_time++;
   }
   printf("\nEl programa ha tardado menos del tiempo estipulado %d veces\n",min_time);
   printf("El programa ha tardado más del tiempo estipulado %d veces\n",max_time);
   printf("El programa ha estado dentro de los valores estipulados %d veces\n",exact_time);
   printf("En total la ejecuccion ha tomado %d segundos\n",total);
}
